//pregunta 1: Porque es una actividad que se repite en bucle hasta que llega a una meta
//pregunta 2: El punto de partida del bucle empieza con el corredor o corredores en el kilometro 0 con cero caramelos
//pregunta 3: Cuando los corredores sobrepasen el kilometro 10
//pregunta 4: El programa sabra parar porque le estamos pidiendo a la computadora para cuando los corredores llegan al kilometro 10 o lo sobrepasan
//pregunta 5: Al menos en mi programa va a ser de 1km por bucle y un caramelo cada 3km
//pregunta 6: La de kilometros recorridos y la de los caramelos 
var km = 0;
var caramelos= 0
while (km <= 10) {    
    console.log('cantidad de kilometros recorridos', km);  
    km++;    
    {
        if (km == 4 || km == 10|| km == 7){
            caramelos++;
        }
        
        console.log('cantidad de caramelos es ', caramelos);
      }
    }
    