var altura=99; //si la altura o edad es mas baja o igual que 99 no va a poder subir y si la edad es menor o igual a 9 tampoco
var edad=9;
if (altura >= 100 && edad >= 10){
    console.log("!Subete,chico!");
} else {console.log("!Lo siento, chico. Tal vel el proximo año!")
}