function Bienvenidos(person, horario) {
  if ( person == "Count Dooku" ){
    console.log("Detente ahi Dooku!! Tu no puedes pasar voy a por ti!!") } else {
  console.log("buenos dias!", person, "horario de bienvenida:", horario);
  
  }
}
Bienvenidos("Ahsoka Tano!", "7am");
Bienvenidos("Count Dooku" , "8am" );
Bienvenidos("Kit Fisto!","8pm");
